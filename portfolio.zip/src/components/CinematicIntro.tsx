import { useEffect, useState } from "react";

export function CinematicIntro() {
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem("introShown") === "1") {
      setHidden(true);
      return;
    }
    sessionStorage.setItem("introShown", "1");
    const t = setTimeout(() => setHidden(true), 4500);
    return () => clearTimeout(t);
  }, []);

  if (hidden) return null;

  const name = "AHMED";

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-background animate-intro-fadeout overflow-hidden pointer-events-none"
      aria-hidden="true"
    >
      {/* radial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,oklch(0.78_0.18_200/0.25),transparent_60%)]" />
      {/* vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,oklch(0_0_0/0.85)_100%)]" />

      <div className="relative">
        <h1
          style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          className="text-7xl md:text-9xl lg:text-[10rem] font-bold text-gradient tracking-tight"
        >
          {name.split("").map((ch, i) => (
            <span
              key={i}
              className="cinematic-letter"
              style={{ animationDelay: `${0.15 * i}s` }}
            >
              {ch}
            </span>
          ))}
        </h1>
        {/* light sweep over name */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div
            className="absolute top-0 -left-1/2 w-1/3 h-full animate-light-sweep"
            style={{
              background:
                "linear-gradient(120deg, transparent 0%, oklch(1 0 0 / 0.25) 50%, transparent 100%)",
            }}
          />
        </div>
      </div>
    </div>
  );
}