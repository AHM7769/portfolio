import { Github, Linkedin, Mail, MapPin, Phone } from "lucide-react";
import { SectionTitle } from "./About";

function ContactCard({ icon: Icon, label, value, href }: { icon: any; label: string; value: string; href?: string }) {
  const content = (
    <div className="p-5 rounded-xl bg-card border border-border hover:border-primary/60 transition-smooth h-full">
      <Icon className="text-primary mx-auto mb-2" size={20} />
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="font-medium text-sm">{value}</div>
    </div>
  );
  return href ? (
    <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer">
      {content}
    </a>
  ) : (
    content
  );
}

function SocialButton({ href, icon: Icon, label }: { href: string; icon: any; label: string }) {
  return (
    <a
      href={href}
      target={href.startsWith("http") ? "_blank" : undefined}
      rel="noreferrer"
      aria-label={label}
      className="w-12 h-12 rounded-full bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary hover:shadow-glow transition-smooth"
    >
      <Icon size={18} />
    </a>
  );
}

export function Contact() {
  return (
    <section id="contact" className="py-24 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.78_0.16_210/0.12),transparent_60%)]" />
      <div className="relative max-w-4xl mx-auto px-6 text-center">
        <SectionTitle eyebrow="Get in touch" title="Let's build something insightful" />
        <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto">
          Open to internships, freelance and full-time opportunities in data analytics. Reach out — I usually reply within a day.
        </p>
        <a
          href="mailto:aahhmmed12335@gmail.com"
          className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-gradient-primary text-primary-foreground font-semibold text-lg hover:shadow-glow transition-smooth mb-12"
        >
          <Mail size={20} /> aahhmmed12335@gmail.com
        </a>
        <div className="grid sm:grid-cols-3 gap-4 max-w-2xl mx-auto">
          <ContactCard icon={Phone} label="Phone" value="+20 106 4535455" href="tel:+201064535455" />
          <ContactCard icon={MapPin} label="Location" value="Cairo, Egypt" />
          <ContactCard icon={Github} label="GitHub" value="@AHM7769" href="https://github.com/AHM7769" />
        </div>
        <div className="flex justify-center gap-5 mt-12">
          <SocialButton href="https://github.com/AHM7769" icon={Github} label="GitHub" />
          <SocialButton href="https://linkedin.com/in/ahmed-mostafa" icon={Linkedin} label="LinkedIn" />
          <SocialButton href="mailto:aahhmmed12335@gmail.com" icon={Mail} label="Email" />
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="py-8 border-t border-border">
      <div className="max-w-6xl mx-auto px-6 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} Ahmed Abdelghany. Crafted with care.
      </div>
    </footer>
  );
}
