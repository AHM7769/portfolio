import { Briefcase, GraduationCap } from "lucide-react";
import { SectionTitle } from "./About";

const items = [
  {
    type: "work" as const,
    period: "2025 – 2026",
    title: "Junior Data Analyst (Remote)",
    org: "Ard El Marah Company",
    points: [
      "Analyzed company data to identify trends and support business decisions.",
      "Built interactive dashboards to track performance and visualize key metrics.",
      "Cleaned and processed raw data to ensure accuracy and consistency.",
    ],
    tech: ["Excel", "Power BI", "SQL"],
  },
  {
    type: "edu" as const,
    period: "2022 – 2026",
    title: "CHI Computer Science & Information",
    org: "Faculty of Computers and Information",
    points: ["Focus on programming, data analysis and computer systems."],
    tech: [] as string[],
  },
  {
    type: "edu" as const,
    period: "2025",
    title: "Data Analysis Certification",
    org: "Online Learning Platforms",
    points: ["Specialized courses in Python, SQL, Excel and Power BI."],
    tech: [] as string[],
  },
];

export function Experience() {
  return (
    <section id="experience" className="py-24">
      <div className="max-w-6xl mx-auto px-6">
        <SectionTitle eyebrow="Journey" title="Experience & education" />
        <div className="relative max-w-3xl mx-auto">
          <div className="absolute left-4 top-0 bottom-0 w-px bg-gradient-to-b from-primary/60 via-border to-transparent" />
          <div className="space-y-10">
            {items.map((it, i) => (
              <div key={i} className="relative pl-12">
                <div className="absolute left-4 top-2 w-3 h-3 rounded-full bg-gradient-primary -translate-x-1/2 ring-4 ring-background" />
                <div className="text-sm font-semibold text-primary mb-1">{it.period}</div>
                <h3 style={{ fontFamily: "'Space Grotesk', sans-serif" }} className="text-xl font-bold">
                  {it.title}
                </h3>
                <div className="text-muted-foreground mb-3 flex items-center gap-2 text-sm">
                  {it.type === "work" ? <Briefcase size={14} /> : <GraduationCap size={14} />}
                  {it.org}
                </div>
                <ul className="space-y-1.5 text-muted-foreground text-sm list-disc list-inside">
                  {it.points.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
                {it.tech.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {it.tech.map((t) => (
                      <span key={t} className="text-xs px-2.5 py-1 rounded-md bg-secondary text-secondary-foreground">
                        {t}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
