import { GraduationCap, Languages, MapPin, Check } from "lucide-react";

export function SectionTitle({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="mb-14 max-w-2xl">
      <div className="text-sm font-semibold uppercase tracking-[0.2em] text-primary mb-3">{eyebrow}</div>
      <h2
        style={{ fontFamily: "'Space Grotesk', sans-serif" }}
        className="text-4xl md:text-5xl font-bold tracking-tight"
      >
        {title}
      </h2>
    </div>
  );
}

function InfoCard({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/50 transition-smooth">
      <div className="w-10 h-10 rounded-lg bg-gradient-primary flex items-center justify-center text-primary-foreground">
        <Icon size={18} />
      </div>
      <div>
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-foreground font-medium">{value}</div>
      </div>
    </div>
  );
}

export function About() {
  return (
    <section id="about" className="py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        <SectionTitle eyebrow="About me" title="Data-driven by curiosity" />
        <div className="grid md:grid-cols-[2fr_1fr] gap-12 items-start">
          <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              I'm an aspiring <span className="text-foreground font-medium">Data Analyst</span> with a
              strong interest in data-driven decision making. I love collecting, cleaning and analyzing
              data to extract meaningful insights that solve real-world problems.
            </p>
            <ul className="space-y-3 text-base">
              {[
                "Currently studying Computer Science at CHI",
                "Building interactive dashboards with Power BI & Excel",
                "Cleaning & analyzing datasets using Python and SQL",
                "Turning raw numbers into clear, actionable insights",
                "Always learning new tools to sharpen my analytical edge",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-1 w-5 h-5 rounded-md bg-gradient-primary flex items-center justify-center text-primary-foreground shrink-0">
                    <Check size={12} strokeWidth={3} />
                  </span>
                  <span className="text-foreground/90">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="space-y-3">
            <InfoCard icon={MapPin} label="Location" value="Cairo, Egypt" />
            <InfoCard icon={GraduationCap} label="Education" value="CHI Computer Science" />
            <InfoCard icon={Languages} label="Languages" value="English B2+ · Arabic Native" />
          </div>
        </div>
      </div>
    </section>
  );
}