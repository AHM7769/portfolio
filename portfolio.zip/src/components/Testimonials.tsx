import { Quote } from "lucide-react";
import { SectionTitle } from "./About";

const items = [
  { quote: "Ahmed delivered a Power BI dashboard that completely changed how we read our sales numbers. Clear, fast and reliable.", name: "Operations Lead", role: "Ard El Marah Company" },
  { quote: "Strong analytical mindset paired with a real eagerness to learn. He picks up new tools quickly and ships clean work.", name: "Project Mentor", role: "Data Analysis Bootcamp" },
  { quote: "His SQL reporting saved us hours of manual work every week. Detail-oriented and easy to collaborate with.", name: "Team Member", role: "Coursework Project" },
];

export function Testimonials() {
  return (
    <section className="py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        <SectionTitle eyebrow="Kind words" title="What people say" />
        <div className="grid md:grid-cols-3 gap-6">
          {items.map((t, i) => (
            <div key={i} className="relative p-8 rounded-2xl bg-card border border-border shadow-card hover:border-primary/40 transition-smooth">
              <Quote className="text-primary mb-4" size={28} />
              <p className="text-muted-foreground leading-relaxed mb-6">"{t.quote}"</p>
              <div className="border-t border-border pt-4">
                <div className="font-semibold text-foreground">{t.name}</div>
                <div className="text-sm text-muted-foreground">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
