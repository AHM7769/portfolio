import { ArrowRight, Download, Github, Linkedin, Mail } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import profilePic from "@/assets/profile.jpeg";

export function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex items-center overflow-hidden pt-16">
      <img
        src={heroBg}
        alt=""
        width={1920}
        height={1280}
        className="absolute inset-0 w-full h-full object-cover opacity-40 animate-ken-burns"
      />
      <div className="absolute inset-0 bg-gradient-hero opacity-80" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.78_0.16_210/0.15),transparent_60%)]" />

      <div className="relative max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-[1fr_auto] gap-10 md:gap-12 items-center w-full">
        <div className="space-y-8 animate-fade-up order-2 md:order-1">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-card/60 border border-border backdrop-blur-sm text-sm text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" />
            Available for opportunities
          </div>

          <h1
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.95] tracking-tight"
          >
            <span className="text-gradient">Ahmed Abdelghany</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-xl leading-relaxed">
            Aspiring <span className="text-foreground font-semibold">Data Analyst & Engineer</span> turning
            raw numbers into clear, actionable insights with Python, SQL, and Power BI.
          </p>

          <div className="flex flex-wrap gap-4">
            <a
              href="#projects"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-primary text-primary-foreground font-semibold hover:shadow-glow transition-smooth"
            >
              View my work <ArrowRight size={18} />
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border border-border bg-card/40 backdrop-blur-sm text-foreground font-semibold hover:border-primary hover:text-primary transition-smooth"
            >
              <Download size={18} /> Get in touch
            </a>
          </div>

          <div className="flex items-center gap-5 pt-4">
            <a href="https://github.com/AHM7769" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary transition-smooth" aria-label="GitHub">
              <Github size={22} />
            </a>
            <a href="https://linkedin.com/in/ahmed-mostafa" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary transition-smooth" aria-label="LinkedIn">
              <Linkedin size={22} />
            </a>
            <a href="mailto:aahhmmed12335@gmail.com" className="text-muted-foreground hover:text-primary transition-smooth" aria-label="Email">
              <Mail size={22} />
            </a>
          </div>
        </div>

        <div className="relative animate-float order-1 md:order-2 mx-auto md:mx-0">
          <div className="absolute -inset-6 bg-gradient-primary blur-3xl opacity-40 rounded-full animate-pulse-glow" />
          <div className="relative w-48 h-48 sm:w-64 sm:h-64 lg:w-80 lg:h-80 rounded-full border-2 border-primary/40 shadow-elegant overflow-hidden">
            <img
              src={profilePic}
              alt="Ahmed Abdelghany portrait"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
          </div>
          <div className="absolute -bottom-4 -right-4 px-4 py-2 rounded-lg bg-card border border-border shadow-card text-sm">
            <div className="text-xs text-muted-foreground">Based in</div>
            <div className="font-semibold">Cairo, Egypt 🇪🇬</div>
          </div>
        </div>
      </div>
    </section>
  );
}