import { ArrowUpRight, BarChart3, Database, FileSpreadsheet, LineChart } from "lucide-react";
import { SectionTitle } from "./About";

const projects = [
  {
    tag: "Power BI",
    icon: BarChart3,
    title: "Ard El Marah — Interactive Dashboard",
    description:
      "Interactive dashboard analyzing company performance, sales trends, customer behavior, and key business metrics through clean visualizations.",
    skills: ["Power BI", "DAX", "Data Modeling"],
  },
  {
    tag: "Python",
    icon: LineChart,
    title: "Sales Data Analysis (EDA)",
    description:
      "Exploratory data analysis on sales data — uncovering trends, patterns and key insights using Pandas, Matplotlib and Seaborn.",
    skills: ["Python", "Pandas", "Matplotlib", "Seaborn"],
  },
  {
    tag: "SQL",
    icon: Database,
    title: "Database Analysis Project",
    description:
      "Wrote advanced SQL queries to extract, filter and analyze data from databases — generating reports to support business decision-making.",
    skills: ["SQL Server", "Joins", "CTEs", "Reporting"],
  },
  {
    tag: "Excel",
    icon: FileSpreadsheet,
    title: "Simple Data Dashboard",
    description:
      "Clean Excel dashboard combining charts and pivot tables to deliver fast, digestible insights and summaries from raw data.",
    skills: ["Excel", "Pivot Tables", "Charts"],
  },
];

export function Projects() {
  return (
    <section id="projects" className="py-24 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,oklch(0.78_0.16_210/0.08),transparent_60%)]" />
      <div className="relative max-w-6xl mx-auto px-6">
        <SectionTitle eyebrow="Selected work" title="Projects that tell a story" />
        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((p) => (
            <article
              key={p.title}
              className="group relative p-8 rounded-2xl bg-card border border-border hover:border-primary/60 transition-smooth shadow-card hover:shadow-glow"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center text-primary-foreground">
                  <p.icon size={22} />
                </div>
                <span className="text-xs font-semibold uppercase tracking-wider text-primary px-3 py-1 rounded-full bg-primary/10 border border-primary/20">
                  {p.tag}
                </span>
              </div>
              <h3
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                className="text-xl font-bold mb-3 group-hover:text-primary transition-smooth flex items-center gap-2"
              >
                {p.title}
                <ArrowUpRight
                  size={18}
                  className="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-smooth"
                />
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-5">{p.description}</p>
              <div className="flex flex-wrap gap-2">
                {p.skills.map((s) => (
                  <span key={s} className="text-xs px-2.5 py-1 rounded-md bg-secondary text-secondary-foreground">
                    {s}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}