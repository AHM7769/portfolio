import { Code2, BarChart3, Wrench } from "lucide-react";
import { SectionTitle } from "./About";

const groups = [
  { icon: Code2, title: "Languages", items: ["Python", "SQL", "JavaScript", "C++", "HTML", "CSS"] },
  { icon: BarChart3, title: "Analysis", items: ["Data Cleaning", "Visualization", "Exploratory Data Analysis (EDA)"] },
  { icon: Wrench, title: "Tools", items: ["Excel", "Power BI", "SQL Server", "Google Sheets", "Jupyter Notebook"] },
];

export function Skills() {
  return (
    <section id="skills" className="py-24">
      <div className="max-w-6xl mx-auto px-6">
        <SectionTitle eyebrow="Toolkit" title="Skills & technologies" />
        <div className="grid md:grid-cols-3 gap-6">
          {groups.map((g) => (
            <div key={g.title} className="p-8 rounded-2xl bg-card border border-border hover:border-primary/60 transition-smooth shadow-card">
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center text-primary-foreground mb-5">
                <g.icon size={22} />
              </div>
              <h3 style={{ fontFamily: "'Space Grotesk', sans-serif" }} className="text-xl font-bold mb-4">
                {g.title}
              </h3>
              <div className="flex flex-wrap gap-2">
                {g.items.map((s) => (
                  <span key={s} className="text-sm px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground border border-border hover:border-primary/40 hover:text-primary transition-smooth">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
